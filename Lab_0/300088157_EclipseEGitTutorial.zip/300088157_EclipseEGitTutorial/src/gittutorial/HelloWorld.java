package gittutorial;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Tutorial V1");
	}
}
